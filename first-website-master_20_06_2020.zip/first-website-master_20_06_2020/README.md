 Starter project to build your first website.  
Scaler Academy, Build a website Workshop
https://www.scaler.com
